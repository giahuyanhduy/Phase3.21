const SERIAL_PORT = "/dev/ttyUSB0";
//const SERIAL_PORT = "/dev/LACHONG";

let ID_CONG_TY = "-1";

const TYPE_PORT_CONFIG = {
    TCP: 1,
    COM: 2
}

const CONFIG_PORT = {
	1: {
        id: 1,
        com: SERIAL_PORT,
        ip: '192.168.1.254',
        portTCP: 30003,
        type: TYPE_PORT_CONFIG.COM
    }, 
    2: {
        id: 2,
        com: SERIAL_PORT,
        ip: '192.168.1.254',
        portTCP: 30003,
        type: TYPE_PORT_CONFIG.COM
    }, 
    3: {
        id: 3,
        com: SERIAL_PORT,
        ip: '192.168.1.254',
        portTCP: 30003,
        type: TYPE_PORT_CONFIG.COM
    },
	4: {
        id: 4,
        com: SERIAL_PORT,
        ip: '192.168.1.254',
        portTCP: 30003,
        type: TYPE_PORT_CONFIG.COM
    } 
	,
	5: {
        id: 5,
        com: SERIAL_PORT,
        ip: '192.168.1.254',
        portTCP: 30003,
        type: TYPE_PORT_CONFIG.COM
    } 
	,
	6: {
        id: 6,
        com: SERIAL_PORT,
        ip: '192.168.1.254',
        portTCP: 30003,
        type: TYPE_PORT_CONFIG.COM
    } 
	,
	7: {
        id: 7,
        com: SERIAL_PORT,
        ip: '192.168.1.254',
        portTCP: 30003,
        type: TYPE_PORT_CONFIG.COM
    } 
	,
	8: {
        id: 8,
        com: SERIAL_PORT,
        ip: '192.168.1.254',
        portTCP: 30003,
        type: TYPE_PORT_CONFIG.COM
    }
	 
};


	
// xu ly neu CONFIG PORT TCP K CO COM
Object.keys(CONFIG_PORT).forEach(key => {
    if (CONFIG_PORT[key].type === TYPE_PORT_CONFIG.TCP) {
        CONFIG_PORT[key].com = CONFIG_PORT[key].ip+CONFIG_PORT[key].portTCP;
    }
});

 
const CONFIG_DATABASE = {
    server: "localhost",
    database: "",
    user: "",
    password: "",
    port: 1433,
    options: {
        "encrypt": true
    },
    pool: {
        "max": 200,
        "min": 20,
        "idleTimeoutMillis": 30000
    },
    connectionTimeout: 300000,
    requestTimeout: 300000,
};


const CONFIG_METRO = {
    0: "Not SET",
    1: "DO 0.05S",
    2: "E5RON92",
    3: "RON95",
	4: "DO 0.01S",
	5: "E5RON92-II",
	6: "RON95-III",
	7: "RON95-IV",
	8: "DO 0.25S",
	9: "KO",
	10: "RON97-V",
	11: "-11-",
	12: "-12-",
	13: "-13-",
	14: "-14-",
	15: "-15-"
};

function getMetroName(id) {
    if (+id === +id)
        return CONFIG_METRO[id&15] || "";
    return CONFIG_METRO
}


function getIDCT() {
    return ID_CONG_TY;
   
}

function setIDCT(IDCT) {
    ID_CONG_TY = IDCT;
   
}


function getCOM() {
    return SERIAL_PORT;
   
}

function getAllPortConnect() {
    let arr = []
    Object.values(CONFIG_PORT).forEach(i => {
        /*if (!arr.includes(i.com.toUpperCase())) {
            arr.push(i.com.toUpperCase());
        }*/
				
		if (!arr.includes(i.com)) {
            arr.push(i.com);
        }
		
		
    });
    return arr;
}

function getComNameFromId(id) {
    return CONFIG_PORT[id];
}

function isPump(id) {
    return Boolean(CONFIG_PORT[id])
}

function getAllPump(type = 'arr') {
    if (type !== 'arr')
        return CONFIG_PORT;
    return Object.values(CONFIG_PORT);
}

module.exports = {
   getCOM, setIDCT,getIDCT, getAllPump, getAllPortConnect, isPump, getMetroName, CONFIG_DATABASE, TYPE_PORT_CONFIG,getComNameFromId
}